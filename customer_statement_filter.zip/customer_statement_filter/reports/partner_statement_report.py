from odoo import models, api, fields

class PartnerStatementReport(models.AbstractModel):
    _name = 'report.customer_statement_filter.report_details'

    @api.model
    def _get_report_values(self, docids, data=None):
        date_from = data.get('date_from')
        date_to = data.get('date_to') or fields.Date.today()
        
        docs = []
        partners = self.env['res.partner'].browse(docids)
        
        for partner in partners:
            # 1. Calculate Opening Balance (Everything before date_from)
            opening_balance = 0.0
            if date_from:
                move_lines_before = self.env['account.move.line'].search([
                    ('partner_id', '=', partner.id),
                    ('account_id.account_type', '=', 'asset_receivable'),
                    ('parent_state', '=', 'posted'),
                    ('date', '<', date_from)
                ])
                opening_balance = sum(move_lines_before.mapped('debit')) - sum(move_lines_before.mapped('credit'))

            # 2. Get Activity (Transactions between dates)
            domain = [
                ('partner_id', '=', partner.id),
                ('account_id.account_type', '=', 'asset_receivable'),
                ('parent_state', '=', 'posted'),
                ('date', '<=', date_to)
            ]
            if date_from:
                domain.append(('date', '>=', date_from))
            
            lines = self.env['account.move.line'].search(domain, order='date asc, id asc')

            # 3. Build the Running Balance
            statement_lines = []
            current_balance = opening_balance
            for line in lines:
                amount = line.debit - line.credit
                current_balance += amount
                statement_lines.append({
                    'date': line.date,
                    'ref': line.move_id.name or line.name,
                    'debit': line.debit,
                    'credit': line.credit,
                    'balance': current_balance,
                })

            docs.append({
                'partner': partner,
                'opening_balance': opening_balance,
                'lines': statement_lines,
                'final_balance': current_balance,
            })

        return {
            'doc_ids': docids,
            'doc_model': 'res.partner',
            'docs': docs,
        }